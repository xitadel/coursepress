<div class="cp_popup_overall"></div>
<div class="cp_popup_window">
	<div class="cp_popup_window_inner">
	    <div class="cp_popup_close_button"></div>
	    <div class="cp_popup_loading"></div>
	    <div class="cp_popup_content">
	        <!--ajax step content goes here-->
	    </div>
    </div>
</div>